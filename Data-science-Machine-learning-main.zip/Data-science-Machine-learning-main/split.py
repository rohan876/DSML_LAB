t = "i am sad"
l1 = t.split()
if l1[0]=="fine" or l1[1]=="fine" or l1[2]=="fine":
    print("positive")
else:
    print("negative")

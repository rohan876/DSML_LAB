str1 = "welcome to my world"
print(str1)
print(str1[0:7])
print(str1)
print(str1[2:5]+str1[8:10]*5)
